

import UIKit

class FRStoryViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,delegateReloadCell {
    
    @IBOutlet var storyTableView: UITableView!
    var loginInfoDictionary :NSMutableDictionary!
    
    var isCommentClicked : Bool = false
    var userStoryArray = [[String:Any]]()
    
    var pageIndex : Int = 0
    var requestURL: URL!

    var fromViewController : String  = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loginInfoDictionary = NSKeyedUnarchiver.unarchiveObject(with: kUserDefault.value(forKey: kloginInfo) as! Data) as! NSMutableDictionary
        
        self.getUserStoryList()
    }
    
    // MARK TableView Deleage ////////////////////////////////////////////
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return userStoryArray.count
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        var dict = userStoryArray[section]
        
        if  dict[kIsShowComment] as? String == "1"  &&  dict[kIsShowComment] != nil{
            return 60
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        var dict = userStoryArray[section]
       
        if  dict[kIsShowComment] as? String == "1"  &&  dict[kIsShowComment] != nil{
            
            let headerView = UIView(frame: CGRect(x: 0, y: 0, width: ScreenSize.width, height: 60))
            headerView.backgroundColor = UIColor.clear
            
            let commnetTextField = UITextField(frame: CGRect(x: 10, y: 5, width: ScreenSize.width-20, height: 30))
            commnetTextField.backgroundColor = UIColor.clear
            commnetTextField.font = UIFont.systemFont(ofSize: 14)
            commnetTextField.placeholder = "Write a comment"
            commnetTextField.returnKeyType = .done
            commnetTextField.borderStyle = .roundedRect
            headerView.addSubview(commnetTextField)
            
            let commnetButton = UIButton(frame: CGRect(x: ScreenSize.width-150, y: 40, width: 150, height: 15))
            commnetButton.setTitleColor(.red, for: .normal)
            commnetButton.setTitle("View Comments", for: .normal)
            commnetButton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
            commnetButton.addTarget(self, action: #selector(viewAllcommentAction(_:)), for: .touchUpInside)
            headerView.addSubview(commnetButton)
            
            return headerView
        }
        return nil
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let identifier = "cell"
        
        var cell: StoryViewCell! = tableView.dequeueReusableCell(withIdentifier: identifier) as? StoryViewCell
        
        tableView.register(UINib(nibName: "StoryViewCell", bundle: nil), forCellReuseIdentifier: identifier)
        cell = (tableView.dequeueReusableCell(withIdentifier: identifier) as? StoryViewCell)!
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        // Button Action
        cell.commentButton.tag = indexPath.section
        cell.commentButton.addTarget(self, action:  #selector(commentButtonAction(_:)), for: .touchUpInside)
        cell.commentButton.addTarget(self, action:  #selector(shareButtonAction(_:)), for: .touchUpInside)
        
        cell.reloadDelegate = self
        cell.setStoryCellData(userStoryArray: &userStoryArray, index: indexPath.section)
        cell.readMoreButton.addTarget(self, action: #selector(readMoreButtonAction(_:)), for: .touchUpInside)
 
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        var height : Float = 0.0
        let dict = userStoryArray[indexPath.section]
        
        // description
        
         let description : String = dict[kDescription] as! String
        height = Float(description.height(withConstrainedWidth: ScreenSize.width - 40, font: UIFont(name: "SFUIText-Regular", size: 14)!))
        
        if height > Float(descriptioHeight) && (dict[kIsReadMore] == nil ||  dict[kIsReadMore] as? String == "1") {
            height = Float(descriptioHeight) + 20 // read more button
        }
       
        let locality : String =  dict[kStoreAddress] as? String ?? ""
        height = Float(locality.height(withConstrainedWidth: ScreenSize.width - 170, font: UIFont(name: "SFUIText-Regular", size: 13)!)) + height

        return CGFloat(storyCellHeight) + CGFloat(height);
    }
    
    // MARK Button Action
    
    @objc  func readMoreButtonAction(_ button : UIButton){
        
        var dict = userStoryArray[button.tag]
        dict[kIsReadMore] = "0"
        
        userStoryArray.remove(at: button.tag)
        userStoryArray.insert(dict, at: button.tag)
        
        storyTableView.reloadData()
    }
    func reloadCellData(dict: [String : Any]) {
        
    }
    
    @objc func commentButtonAction(_ button: UIButton) {
        
        var dict = userStoryArray[button.tag]
        
        if  dict[kIsShowComment] as? String == "0"  ||  dict[kIsShowComment] == nil{
            dict[kIsShowComment] = "1"
        }
        else {
            dict[kIsShowComment] = "0"
        }
        
        userStoryArray.remove(at: button.tag)
        userStoryArray.insert(dict, at: button.tag)
        
        self.storyTableView.reloadData()
    }
    
    @objc func shareButtonAction(_ button: UIButton) {
//        let urlString = "https://www.google.com"
//
//        let linkToShare = [urlString]
//        let share = UIActivityViewController(activityItems: linkToShare, applicationActivities: nil)
//        self.present(share, animated: true, completion: nil)
    }
    
    @objc func viewAllcommentAction(_ button : UIButton){
        // view all comment
        
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let commentView : FRCommentViewController = storyboard.instantiateViewController(withIdentifier: kCommentStoryboardID) as! FRCommentViewController
        self.navigationController?.pushViewController(commentView, animated: true)
    }
    
    
    //MARK: - API Call
    
    @objc func getUserStoryList()
    {
        var params: NSMutableDictionary = [:]
      
        print(params)
        if self.fromViewController == kBrandStories {
            params = [
                kCustomerId : loginInfoDictionary[kCustomerId]!,
                kpageNo : pageIndex,
            ]
            requestURL = URL(string: String(format: "%@%@",kBaseUrl,kbrandstory))!
        }
        else {
            params = [
                kCustomerId : loginInfoDictionary[kCustomerId]!,
                kpageNo : pageIndex,
            ]
            requestURL = URL(string: String(format: "%@%@",kBaseUrl,kuserstory))!
            
        }
        
        NetworkManager.sharedInstance.postRequest(requestURL, hude: true, showSystemError: true, loadingText: false, params: params) { (response: NSDictionary?) in
            if (response != nil) {
                
                DispatchQueue.main.async {
                    
                    let dict  = response!
                    let index :String = String(format:"%@", response![kCode]! as! CVarArg)
                    if index == "200" {
                        self.userStoryArray = dict.value(forKey: kPayload) as! [[String : Any]]
                        self.storyTableView.reloadData()
                    }
                    else
                    {
                        let message = dict[kMessage]
                        
                        alertController(controller: self, title: "", message:message! as! String, okButtonTitle: "OK", completionHandler: {(index) -> Void in
                            
                        })
                        
                    }
                }
            }
        }
    }
    
    // MARK : Paging
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = round(storyTableView.contentOffset.x / storyTableView.frame.size.width)
        pageIndex = Int(pageNumber)
      //  getUserStoryList()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }
    
}
